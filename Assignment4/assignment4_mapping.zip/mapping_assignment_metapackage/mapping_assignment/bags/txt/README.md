Text files generate from the bag files. This is not what you usually do in ROS.
It is just to help you debug.
