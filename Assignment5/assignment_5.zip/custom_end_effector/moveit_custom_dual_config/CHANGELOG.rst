^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package moveit_custom_dual_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2021-03-29)
------------------
* Merge branch 'tiago-dual' into 'master'
  feat: dual customisation
  See merge request robots/custom_end_effector!1
* chore: rm fake changelogs
* chore: only gen custom combinations
* chore: generate only custom combinations
* docs: authors, year and consistency
* docs: add TODO comments to each part that need to be modified
* fix: add contiions and generate disable collitions
* fix: base name containing undesired word
* fix: scrit and generate all combinations
* fix: enable srdf creation from em file
* fix: controller_custom with some notes for customer
* WIP: feat: dual customisation
* Contributors: daniellopez, davidfernandez

* Merge branch 'tiago-dual' into 'master'
  feat: dual customisation
  See merge request robots/custom_end_effector!1
* chore: rm fake changelogs
* chore: only gen custom combinations
* chore: generate only custom combinations
* docs: authors, year and consistency
* docs: add TODO comments to each part that need to be modified
* fix: add contiions and generate disable collitions
* fix: base name containing undesired word
* fix: scrit and generate all combinations
* fix: enable srdf creation from em file
* fix: controller_custom with some notes for customer
* WIP: feat: dual customisation
* Contributors: daniellopez, davidfernandez

0.1.0 (2020-04-21)
------------------

0.0.1 (2020-03-26)
------------------
