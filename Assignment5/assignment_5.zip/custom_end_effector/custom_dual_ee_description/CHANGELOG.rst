^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package custom_dual_ee_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2021-03-29)
------------------
* Merge branch 'tiago-dual' into 'master'
  feat: dual customisation
  See merge request robots/custom_end_effector!1
* chore: rm fake changelogs
* docs: authors, year and consistency
* docs: add TODO comments to each part that need to be modified
* fix: repeated link names
* WIP: feat: dual customisation
* Contributors: daniellopez, davidfernandez

* Merge branch 'tiago-dual' into 'master'
  feat: dual customisation
  See merge request robots/custom_end_effector!1
* chore: rm fake changelogs
* docs: authors, year and consistency
* docs: add TODO comments to each part that need to be modified
* fix: repeated link names
* WIP: feat: dual customisation
* Contributors: daniellopez, davidfernandez

0.1.0 (2020-04-21)
------------------

0.0.1 (2020-03-26)
------------------
