# Decay option

- use_decay : Allow the layer to use a decay on the pixel marked. By default set at false.
- pixel_decay : Time decay in seconds. By default set at 10.0.

