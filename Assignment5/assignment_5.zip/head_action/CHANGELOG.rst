^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package head_action
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2015-01-20)
------------------
* Copy PR2 head action and clean up
* Contributors: Bence Magyar, Sammy Pfeiffer
