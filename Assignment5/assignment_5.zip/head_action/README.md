head_action
===========

Robot agnostic head action interface
