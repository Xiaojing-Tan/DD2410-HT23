^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aruco_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2019-09-27)
------------------
* Merge branch 'indigo-devel' into kinetic-devel
* Contributors: Victor Lopez

3.1.3 (2022-11-23)
------------------

3.1.2 (2022-11-10)
------------------

3.1.1 (2022-11-08)
------------------

3.1.0 (2022-11-07)
------------------

3.0.3 (2022-05-16)
------------------

3.0.2 (2022-04-05)
------------------
* Merge pull request #103 from bmagyar/make-sai-maintainer
  Make Sai maintainer of all aruco_ros packages
* Make Sai maintainer of all
* Update license tags in the package.xml
* Contributors: Bence Magyar, Sai Kishor Kothakota

3.0.1 (2022-02-10)
------------------

3.0.0 (2021-07-16)
------------------

2.1.1 (2020-09-17)
------------------

2.1.0 (2020-01-21)
------------------

2.0.2 (2019-11-09)
------------------

2.0.1 (2019-09-27)
------------------

0.2.2 (2017-07-25)
------------------

0.2.1 (2017-07-21)
------------------

0.2.0 (2016-10-19)
------------------

0.1.0 (2015-08-10)
------------------
* Update changelogs and maintainer email
* Contributors: Bence Magyar

0.0.1 (2015-05-20)
------------------
* Reorganize aruco_ros into 3 packages
* Contributors: Bence Magyar
