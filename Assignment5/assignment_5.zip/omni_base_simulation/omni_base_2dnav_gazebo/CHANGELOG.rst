^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_base_2dnav_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.7 (2023-02-23)
------------------
* Merge branch 'feat/share-mmap' into 'ferrum-devel'
  deprecating map_configuration_manager
  See merge request robots/omni_base_simulation!6
* deprecating map_configuration_manager
* Contributors: antoniobrandi

0.0.6 (2023-01-30)
------------------

0.0.5 (2023-01-27)
------------------
* Merge branch 'feat/map-manager' into 'ferrum-devel'
  Move to map manager
  See merge request robots/omni_base_simulation!4
* Move to map manager
* Contributors: antoniobrandi

0.0.4 (2022-08-08)
------------------
* Merge branch 'fix_public_sim' into 'ferrum-devel'
  remove the loading the filter in the public sim to avoid error
  See merge request robots/omni_base_simulation!2
* remove the loading the filter in the public sim to avoid error
* Contributors: antoniobrandi, thomaspeyrucain

0.0.3 (2022-02-23)
------------------
* Merge branch 'layered_costmap' into 'ferrum-devel'
  Adapting to the new vo_server
  See merge request robots/omni_base_simulation!1
* Adapting to the new vo_server
* Contributors: antoniobrandi

0.0.2 (2021-11-24)
------------------

0.0.1 (2021-09-30)
------------------
* preparing release
* adapting to the new version of omni_base_robot
* omni base simulation initial commit
* Contributors: antoniobrandi
