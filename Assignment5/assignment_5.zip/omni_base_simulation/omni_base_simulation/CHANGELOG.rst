^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_base_simulation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.7 (2023-02-23)
------------------

0.0.6 (2023-01-30)
------------------
* Merge branch 'fix/missing-deps' into 'ferrum-devel'
  Added missing dependencies
  See merge request robots/omni_base_simulation!5
* Update package.xml
* Contributors: antoniobrandi

0.0.5 (2023-01-27)
------------------

0.0.4 (2022-08-08)
------------------

0.0.3 (2022-02-23)
------------------

0.0.2 (2021-11-24)
------------------

0.0.1 (2021-09-30)
------------------
* preparing release
* omni base simulation initial commit
* Contributors: antoniobrandi
