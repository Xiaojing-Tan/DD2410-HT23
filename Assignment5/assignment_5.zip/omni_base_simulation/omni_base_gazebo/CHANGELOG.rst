^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_base_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.7 (2023-02-23)
------------------

0.0.6 (2023-01-30)
------------------

0.0.5 (2023-01-27)
------------------

0.0.4 (2022-08-08)
------------------

0.0.3 (2022-02-23)
------------------

0.0.2 (2021-11-24)
------------------
* removing the needs for pid values for the wheels
* Contributors: antoniobrandi

0.0.1 (2021-09-30)
------------------
* preparing release
* adapting to the new version of omni_base_robot
* omni base simulation initial commit
* Contributors: antoniobrandi
