^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_base_laser_sensors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.11 (2023-03-06)
-------------------

0.0.10 (2023-01-27)
-------------------

0.0.9 (2022-08-16)
------------------
* Merge branch 'fix/lasers-fov' into 'ferrum-devel'
  fix lasers fov
  See merge request robots/omni_base_navigation!5
* adjusted fov for sick laser scanner
* fix hokuyo_urg_04lx_ug01_laser fov
* Contributors: antoniobrandi, josegarcia

0.0.8 (2022-08-08)
------------------

0.0.7 (2022-08-04)
------------------

0.0.6 (2022-07-13)
------------------
* Merge branch 'hokuyo-support' into 'ferrum-devel'
  Hokuyo support
  See merge request robots/omni_base_navigation!1
* Update hokuyo_urg_04lx_ug01_laser.yaml
* Assign laser ports
* Update hokuyo_laser.launch
* Update hokuyo_laser.launch
* Update yaml file in launch file
* Update package.xml
* Adding specificatios for hokuyo
* Contributors: David ter Kuile, antoniobrandi, davidterkuile

0.0.5 (2021-10-26)
------------------
* changed laser sensor configuration for the final base
* Contributors: antoniobrandi

0.0.4 (2021-10-06)
------------------

0.0.3 (2021-10-04)
------------------

0.0.2 (2021-09-30)
------------------
* removed unused dempendencies and adding dependency from ira_laser_tools
* Contributors: antoniobrandi

0.0.1 (2021-09-30)
------------------
* preparing release
* adapting to the new urdf convention using virtual_base_laser_link
* Omni base navigation initial commit
* Contributors: antoniobrandi
