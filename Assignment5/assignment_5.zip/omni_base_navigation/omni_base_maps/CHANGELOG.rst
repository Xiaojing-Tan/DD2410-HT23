^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_base_maps
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.11 (2023-03-06)
-------------------
* Merge branch 'add_pal_office_7th_floor_map' into 'ferrum-devel'
  Add new pal office map
  See merge request robots/omni_base_navigation!9
* Add new pal office map
* Contributors: antoniobrandi, thomaspeyrucain

0.0.10 (2023-01-27)
-------------------

0.0.9 (2022-08-16)
------------------

0.0.8 (2022-08-08)
------------------
* Merge branch 'update_rviz' into 'ferrum-devel'
  Add advanced navigation file + fix nav rviz + change poi
  See merge request robots/omni_base_navigation!3
* Add advanced navigation file + fix nav rviz + change poi
* Contributors: antoniobrandi, thomaspeyrucain

0.0.7 (2022-08-04)
------------------

0.0.6 (2022-07-13)
------------------

0.0.5 (2021-10-26)
------------------

0.0.4 (2021-10-06)
------------------
* Updates to omni_base_maps in order to generate the folder in the .pal
* Contributors: antoniobrandi

0.0.3 (2021-10-04)
------------------

0.0.2 (2021-09-30)
------------------

0.0.1 (2021-09-30)
------------------
* preparing release
* Omni base navigation initial commit
* Contributors: antoniobrandi
