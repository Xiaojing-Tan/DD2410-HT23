^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package omni_base_2dnav
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.11 (2023-03-06)
-------------------

0.0.10 (2023-01-27)
-------------------
* Merge branch 'feat/map-manager' into 'ferrum-devel'
  Move to map manager
  See merge request robots/omni_base_navigation!7
* Move to map manager
* Contributors: antoniobrandi

0.0.9 (2022-08-16)
------------------

0.0.8 (2022-08-08)
------------------
* Merge branch 'update_rviz' into 'ferrum-devel'
  Add advanced navigation file + fix nav rviz + change poi
  See merge request robots/omni_base_navigation!3
* Add advanced navigation file + fix nav rviz + change poi
* Contributors: antoniobrandi, thomaspeyrucain

0.0.7 (2022-08-04)
------------------
* Merge branch 'fix-rviz-default' into 'ferrum-devel'
  Modify default rviz to show the right topics and not transparent omni_base
  See merge request robots/omni_base_navigation!2
* Modify default rviz to show the right topics and not transparent omni_base
* Contributors: antoniobrandi, thomaspeyrucain

0.0.6 (2022-07-13)
------------------

0.0.5 (2021-10-26)
------------------

0.0.4 (2021-10-06)
------------------

0.0.3 (2021-10-04)
------------------
* removing useless dependencies
* Contributors: antoniobrandi

0.0.2 (2021-09-30)
------------------

0.0.1 (2021-09-30)
------------------
* preparing release
* Omni base navigation initial commit
* Contributors: antoniobrandi
